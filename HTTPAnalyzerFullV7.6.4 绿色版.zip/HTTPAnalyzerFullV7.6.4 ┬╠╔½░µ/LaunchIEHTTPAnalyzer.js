  
    var objIE;
    HTTPAnalyzerBAR = "{92F2BF89-AEA4-4A97-993E-9128C11F400D}"; //IE HTTP  Analyzer V7
    
    // Create Internet Explorer Object'
    objIE = new ActiveXObject("InternetExplorer.Application");
    objIE.Visible = true
    
    objIE.Navigate("about:blank");
    while (objIE.Busy)
    {
     //wait
    }
   
    //Make sure that the HTTPAnalyzer bar is open
    objIE.ShowBrowserBar(HTTPAnalyzerBAR, true);
    
    
    
    